import './App.css';
import WeeklyGuess from './Components/WeeklyGuess';

function App() {
  return (
    <div>
      <WeeklyGuess />
    </div>
  );
}

export default App;
