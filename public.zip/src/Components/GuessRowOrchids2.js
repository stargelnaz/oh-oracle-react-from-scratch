import SelectOptionsClans from './SelectOptionsClans';
import SelectOptionsQTY from './SelectOptionsQTY';
import './GuessRowResources.css';

function GuessRowOrchids2() {
  return (
    <div>
      <h2 className=''>EPIC ORCHIDS</h2>

      <h2 className=''>LEGENDARY ORCHIDS</h2>

      <h2 className=''>GHOST ORCHIDS</h2>
      {/* <SelectOptionsQTY />
      <SelectOptionsClans /> */}
    </div>
  );
}

export default GuessRowOrchids2;
