import './Guess.css';

function Guess() {
  return (
    <div className='grid-weekly-guess'>
      <div className='grid-weekly-guess'>
        ROW 1 - Resources
        <div></div>
        {/* ROW 2 - Common Orchids */}
        <div className='grid-weekly-guess grid-col-span-2'></div>
        {/* ROW 3 - Rare Orchids */}
        <div></div>
      </div>
    </div>
  );

  <div className='grid-weekly-guess'>
    ROW 1 - Resources
    <div></div>
    {/* ROW 2 - Common Orchids */}
    <div className='grid-weekly-guess grid-col-span-2'></div>
    {/* ROW 3 - Rare Orchids */}
    <div></div>
  </div>;
}
export default Guess;
